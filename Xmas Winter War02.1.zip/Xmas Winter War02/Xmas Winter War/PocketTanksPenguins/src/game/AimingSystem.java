package game;

import java.util.ArrayList;
import java.util.List;

/**
 * AimingSystem
 * ---------------------------
 * Takes angle/power and generates projectile(s)
 * used by firing logic in AnimGLEventListener3/GameManager.
 * * MODIFIED: Removed the explicit flip of vx. The angle passed to fireInit must now
 * account for the player's direction.
 */

public class AimingSystem {

    // Return value for projectile creation
    public static class ProjectileInit {
        public List<GameManager.Projectile> list = new ArrayList<>();
    }

    /**
     * Create projectile(s) depending on weapon type.
     * @param angle Firing angle in degrees (the listener handles player direction).
     * @param initialFacingRight The direction the active player is facing (used only for projectile drawing).
     */
    public ProjectileInit fireInit(float x, float y, float angle, float power,
                                   GameManager.WeaponType weapon,
                                   boolean initialFacingRight) {

        ProjectileInit out = new ProjectileInit();

        // 1. Calculate initial velocities based on angle and power
        float rad = (float)Math.toRadians(angle);
        float magnitude = power * 0.4f;

        float vx = (float)Math.cos(rad) * magnitude;
        float vy = (float)Math.sin(rad) * magnitude;

        // REMOVED STEP: The explicit flip of vx is no longer needed because the
        // AnimGLEventListener3 now adjusts the 'angle' based on the player's facing direction.

        switch (weapon) {

            case NORMAL:
                out.list.add(new GameManager.Projectile(x, y, vx, vy, weapon, initialFacingRight));
                break;

            case BOUNCE:
                out.list.add(new GameManager.Projectile(x, y, vx, vy, weapon, initialFacingRight));
                break;

            case CLUSTER:
                out.list.add(new GameManager.Projectile(x, y, vx, vy, weapon, initialFacingRight));
                break;
        }

        return out;
    }
}