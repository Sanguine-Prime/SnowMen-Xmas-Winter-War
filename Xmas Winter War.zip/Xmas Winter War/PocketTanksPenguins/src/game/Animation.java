package game;

public class Animation {
    public int startIndex;
    public int endIndex;
    public int frameCount;
    public int currentFrame = 0;
    public int fps = 8;
    private long lastFrameTime = 0;

    public Animation(int start, int end) {
        this.startIndex = start;
        this.endIndex = end;
        this.frameCount = end - start + 1;
    }

    public int getFrame() {
        long now = System.currentTimeMillis();
        if (now - lastFrameTime > (1000 / fps)) {
            lastFrameTime = now;
            currentFrame = (currentFrame + 1) % frameCount;
        }
        return startIndex + currentFrame;
    }

    public void reset() {
        currentFrame = 0;
    }
}
