package game;

import java.util.ArrayList;
import java.util.List;

/**
 * AimingSystem
 * ---------------------------
 * Takes angle/power and generates projectile(s)
 * used by firing logic in AnimGLEventListener3/GameManager.
 */

public class AimingSystem {

    // Return value for projectile creation
    public static class ProjectileInit {
        public List<GameManager.Projectile> list = new ArrayList<>();
    }

    /**
     * Create projectile(s) depending on weapon type.
     */
    public ProjectileInit fireInit(float x, float y, float angle, float power,
                                   GameManager.WeaponType weapon) {

        ProjectileInit out = new ProjectileInit();

        float rad = (float)Math.toRadians(angle);
        float vx = (float)Math.cos(rad) * (power * 0.4f);
        float vy = (float)Math.sin(rad) * (power * 0.4f);

        switch (weapon) {

            case NORMAL:
                out.list.add(new GameManager.Projectile(x, y, vx, vy, weapon));
                break;

            case BOUNCE:
                out.list.add(new GameManager.Projectile(x, y, vx, vy, weapon));
                break;

            case CLUSTER:
                // initial “launcher” projectile; splits on impact
                out.list.add(new GameManager.Projectile(x, y, vx, vy, weapon));
                break;
        }

        return out;
    }
}
