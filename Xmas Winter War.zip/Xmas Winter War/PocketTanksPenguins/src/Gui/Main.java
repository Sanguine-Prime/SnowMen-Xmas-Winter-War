package Gui;
public class Main {
    public static void main(String[] args) {
        GameFrame frame = new GameFrame();
    }
}