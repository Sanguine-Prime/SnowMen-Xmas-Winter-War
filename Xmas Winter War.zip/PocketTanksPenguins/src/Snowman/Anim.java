package Snowman;

import com.sun.opengl.util.Animator;
import com.sun.opengl.util.FPSAnimator;
import javax.media.opengl.GLCanvas;
import javax.swing.*;
import java.awt.*;

// New imports required for the TextureLoader logic
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GL;

/**
 * Main application class that sets up the JFrame, GLCanvas, and triggers
 * the initial texture loading using the TextureLoader class.
 */
public class Anim extends JFrame {

    public static void main(String[] args) {
        // Run the main window setup on the Event Dispatch Thread (Swing standard practice)
        SwingUtilities.invokeLater(() -> new Anim());
    }

    public Anim() {
        GLCanvas glcanvas;
        Animator animator;

        AnimGLEventListener3 listener = new AnimGLEventListener3();
        glcanvas = new GLCanvas();
        glcanvas.addGLEventListener(listener);
        glcanvas.addKeyListener(listener);
        getContentPane().add(glcanvas, BorderLayout.CENTER);

        animator = new FPSAnimator(60);
        animator.add(glcanvas);
        animator.start();

        setTitle("Xmas SnowMen Wars");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // Using a fixed resolution is common in JOGL for coordinate mapping
        setSize(1920, 1080);
        setLocationRelativeTo(null);
        setVisible(true);
        setFocusable(true);
        glcanvas.requestFocus();
    }
}