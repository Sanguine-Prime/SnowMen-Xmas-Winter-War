package game;

import javax.media.opengl.GL;

/**
 * Renders the health bar UI elements using OpenGL textures in normalized
 * device coordinates (NDC, range -1.0 to 1.0).
 */
public class HealthBar {

    // --- Configuration (Normalized Device Coordinates) ---
    private final float BAR_WIDTH = 0.40f;
    private final float BAR_HEIGHT = 0.05f;

    // Texture IDs injected from AnimGLEventListener3
    private int bgTextureID = -1;
    private int fillTextureID = -1;

    public HealthBar() {}

    /**
     * Setter for texture IDs (injected from AnimGLEventListener3)
     */
    public void setTextureIndices(int bgID, int fillID) {
        this.bgTextureID = bgID;
        this.fillTextureID = fillID;
    }

    /**
     * Renders both player health bars.
     */
    public void draw(GL gl, Player p1, Player p2) {
        if (bgTextureID <= 0 || fillTextureID <= 0) return;

        // P1 Position: Top Left
        final float P1_START_X = -0.95f;
        final float P1_START_Y = 0.82f;
        drawSingleBar(gl, p1.getHp(), 100, P1_START_X, P1_START_Y);

        // P2 Position: Top Right
        final float P2_START_X = 0.95f - BAR_WIDTH;
        final float P2_START_Y = 0.82f;
        drawSingleBar(gl, p2.getHp(), 100, P2_START_X, P2_START_Y);
    }

    /**
     * Renders a single health bar.
     */
    private void drawSingleBar(GL gl, int currentHP, int maxHP, float startX, float startY) {
        float healthRatio = Math.max(0f, (float)currentHP / maxHP);
        float fillWidth = BAR_WIDTH * healthRatio;

        gl.glEnable(GL.GL_TEXTURE_2D);
        gl.glPushMatrix();
        gl.glLoadIdentity();

        // --- 1. Draw Background (Full size) ---
        gl.glBindTexture(GL.GL_TEXTURE_2D, bgTextureID);
        gl.glColor4f(1f, 1f, 1f, 1f); // Ensure neutral white tint for background texture

        gl.glBegin(GL.GL_QUADS);
        gl.glTexCoord2f(0f, 0f); gl.glVertex2f(startX, startY);
        gl.glTexCoord2f(1f, 0f); gl.glVertex2f(startX + BAR_WIDTH, startY);
        gl.glTexCoord2f(1f, 1f); gl.glVertex2f(startX + BAR_WIDTH, startY + BAR_HEIGHT);
        gl.glTexCoord2f(0f, 1f); gl.glVertex2f(startX, startY + BAR_HEIGHT);
        gl.glEnd();

        // --- 2. Draw Fill (Partial width) ---
        if (fillWidth > 0) {
            gl.glBindTexture(GL.GL_TEXTURE_2D, fillTextureID);

            // >>> FIX APPLIED HERE: Set color back to pure white (neutral tint)
            gl.glColor4f(1.0f, 1.0f, 1.0f, 1f);

            // We can optionally re-introduce the color changing logic if desired,
            // but for now, we assume the texture has the desired color.
            /*
            // Optional: Color Tint based on health
            if (healthRatio > 0.5) gl.glColor4f(0.0f, 1.0f, 0.0f, 1f); // Green
            else if (healthRatio > 0.2) gl.glColor4f(1.0f, 1.0f, 0.0f, 1f); // Yellow
            else gl.glColor4f(1.0f, 0.0f, 0.0f, 1f); // Red
            */

            float textureX_end = healthRatio;

            gl.glBegin(GL.GL_QUADS);
            gl.glTexCoord2f(0f, 0f);       gl.glVertex2f(startX, startY);
            gl.glTexCoord2f(textureX_end, 0f); gl.glVertex2f(startX + fillWidth, startY);
            gl.glTexCoord2f(textureX_end, 1f); gl.glVertex2f(startX + fillWidth, startY + BAR_HEIGHT);
            gl.glTexCoord2f(0f, 1f);       gl.glVertex2f(startX, startY + BAR_HEIGHT);
            gl.glEnd();
        }

        gl.glPopMatrix();
        gl.glLoadIdentity();
    }
}