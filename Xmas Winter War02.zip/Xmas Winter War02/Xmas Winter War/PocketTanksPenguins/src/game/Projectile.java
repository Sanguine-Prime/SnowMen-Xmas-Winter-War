package game;

public class Projectile {
    public float x, y;
    public float vx, vy;
    public boolean active = true;

    public Projectile(float x, float y, float power, float angleDegrees) {
        this.x = x;
        this.y = y;
        double rad = Math.toRadians(angleDegrees);
        vx = (float)(power * Math.cos(rad));
        vy = (float)(power * Math.sin(rad));
    }

    public void update() {
        x += vx;
        y += vy;
        vy -= 0.4; // gravity

        if (y < 0) active = false;
    }
}
