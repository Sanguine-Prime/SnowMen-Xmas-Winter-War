package game;

/**
 * Defines player state, attributes, and animation fields.
 */
public class Player {

    // ============================================================
    // Core Attributes
    // ============================================================
    public float x, y;
    public int hp = 100;
    public int lives = 3;
    public float scale = 0.15f;

    // DIRECTION FIX: Tracks which way the player is facing (true = right, false = left)
    public boolean facingRight = true;

    // ============================================================
    // Animation States
    // ============================================================
    public enum AnimState {
        IDLE, ATTACK, HURT, DEATH
    }

    // Animation Fields: These must be present for GameManager logic
    public AnimState anim = AnimState.IDLE;
    public float animTimer = 0f;
    public int currentFrame = 0;

    // IDLE TWITCH FIX: Tracks the direction of the IDLE animation loop (for ping-pong)
    public boolean animForward = true;

    // Texture ID Arrays: Injected by AnimGLEventListener3
    public int[] idleTex;
    public int[] attackTex;
    public int[] hurtTex;
    public int[] deathTex;

    // ============================================================
    // Constructor (Updated to include facing direction)
    // ============================================================
    public Player(float x, float y, boolean facingRight) {
        this.x = x;
        this.y = y;
        this.facingRight = facingRight;
    }

    // ============================================================
    // Utility Methods
    // ============================================================
    public int getHp() { return hp; }
    public int getLives() { return lives; }

    /**
     * Resets animation state back to IDLE, used for end-of-turn cleanup.
     * Also resets the IDLE ping-pong direction.
     */
    public void resetAnimToIdle() {
        if (this.anim != AnimState.DEATH) {
            this.anim = AnimState.IDLE;
            this.animTimer = 0f;
            this.currentFrame = 0;
            this.animForward = true; // Reset ping-pong direction
        }
    }
}