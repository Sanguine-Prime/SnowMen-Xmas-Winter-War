package game;

import javax.media.opengl.GL;

public class CharacterSprite {
    public float x, y;
    public int hp = 100;
    public int lives = 3;

    public Animation idle, attack, hurt, death;
    public boolean isDead = false;

    public CharacterSprite(float x, float y,
                           Animation idle, Animation attack,
                           Animation hurt, Animation death) {

        this.x = x;
        this.y = y;

        this.idle = idle;
        this.attack = attack;
        this.hurt = hurt;
        this.death = death;
    }

    public int getCurrentTexture() {
        if (isDead) return death.getFrame();
        if (hurt.currentFrame != 0) return hurt.getFrame();
        if (attack.currentFrame != 0) return attack.getFrame();
        return idle.getFrame();
    }

    public void draw(GL gl, int[] textures) {
        int tex = getCurrentTexture();
        gl.glBindTexture(GL.GL_TEXTURE_2D, textures[tex]);

        gl.glPushMatrix();
        gl.glTranslatef(x, y, 0);
        gl.glScalef(0.2f, 0.2f, 1);

        gl.glBegin(GL.GL_QUADS);
        gl.glTexCoord2f(0, 0); gl.glVertex2f(-1, -1);
        gl.glTexCoord2f(1, 0); gl.glVertex2f( 1, -1);
        gl.glTexCoord2f(1, 1); gl.glVertex2f( 1,  1);
        gl.glTexCoord2f(0, 1); gl.glVertex2f(-1,  1);
        gl.glEnd();

        gl.glPopMatrix();
    }

    public void takeDamage(int dmg) {
        hp -= dmg;
        if (hp <= 0) {
            lives--;
            hp = 100;
            if (lives < 0) isDead = true;
            death.reset();
        }
        hurt.reset();
    }
}
